﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _55_1_7
{
    class Program
    {
        static string input;
        static bool input_ok = true;
        static bool cord_ok;
        static int sum;
        static Random rnd = new Random();
        static void cord(string ans)
        {
            sum = 0;
            for (int i=0;i<16;i+=2)
            {
                string temp1 = ((ans[i] - '0') * 2).ToString();
                sum += (temp1.Length == 2 ? temp1[0] - '0' + temp1[1] - '0' : int.Parse(temp1)) + (ans[i + 1] - '0') * 1;
            }
            if (sum % 10 == 0)
            {
                cord_ok = true;
            }
            else
            {
                cord_ok = false;
            }
        }
        static void where(string ww)
        {
            switch (ww)
            {
                case "03":
                    Console.Write("此卡片為聯合信用卡");
                    wheree(int.Parse(ww));
                    break;
                case "35":
                    Console.Write("此卡片為 JCB 信用卡");
                    wheree(int.Parse(ww));
                    break;
                case "45":
                    Console.Write("此卡片為 MASTER 信用卡");
                    wheree(int.Parse(ww));
                    break;
                case "54":
                    Console.Write("此卡片為 VISA 信用卡");
                    wheree(int.Parse(ww));
                    break;
                default:
                    Console.Write("非本店特約用戶");
                    wheree(int.Parse(ww));
                    break;
            }
        }
        static void wheree(int www)
        {
            switch (www)
            {
                case int n when (n >=30 && n <= 39):
                    Console.WriteLine("(大中華區)");
                    break;
                case int n when (n >= 40 && n <= 49):
                    Console.WriteLine("(歐美地區)");
                    break;
                default:
                    Console.WriteLine("");
                    break;
            }
        }
        static void some(string inputt)
        {
            for (int i = 0;i < 5; i++)
            {
                cord_ok = false;
                do
                {
                    string anstr = inputt;
                    for (int j = 0; j < 14; j++)
                    {
                        anstr += (rnd.Next(0, 10)).ToString();
                    }
                    if (anstr.All(char.IsDigit) && anstr.Length == 16)
                    {
                        cord(anstr);
                        if (cord_ok)
                        {
                            Console.WriteLine(anstr);
                        }
                    }
                } while (!cord_ok);
            }
        }
        static void Main(string[] args)
        {
            do
            {
                Console.Write("請輸入信用卡號碼>");
                input = Console.ReadLine();
                if (input.All(char.IsDigit) && input.Length == 16)
                {
                    cord(input);
                    if (cord_ok)
                    {
                        input_ok = false;
                        Console.WriteLine("信用卡號碼正確...");
                        where(input[0] + "" + input[1]);
                    }
                    else
                    {
                        Console.WriteLine("信用卡號碼錯誤。");
                    }
                }
                else
                {
                    Console.WriteLine("輸入格式錯誤，請輸入信用卡號碼。");
                }
            } while (input_ok);

            if(!input_ok)
            {
                Console.WriteLine("\n生成五個合法相同卡號...");
                some(input[0] + "" + input[1]);
            }
        }
    }
}
