﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms; 

namespace _55_5_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string hash;
        public static string newPasswordHash;
        public static bool trfa = true;

        private void Form1_Load(object sender, EventArgs e)
        {
            if (!File.Exists("uers.txt"))
            {
                File.WriteAllText("uers.txt", "");
            }
            else
            {
                File.WriteAllText("uers.txt", "");
            }
        }
        public static void password(string input , string textbox)
        {
            switch (input)
            {
                case "SHA256":
                    trfa = true;
                    newPasswordHash = BitConverter.ToString(SHA256.Create().ComputeHash(Encoding.UTF8.GetBytes(textbox))).Replace("-", "");
                    break;
                case "SHA512":
                    trfa = true;
                    newPasswordHash = BitConverter.ToString(SHA512.Create().ComputeHash(Encoding.UTF8.GetBytes(textbox))).Replace("-", "");
                    break;
                case "MD5":
                    trfa = true;
                    newPasswordHash = BitConverter.ToString(MD5.Create().ComputeHash(Encoding.UTF8.GetBytes(textbox))).Replace("-", "");
                    break;
                case "SHA1":
                    trfa = true;
                    newPasswordHash = BitConverter.ToString(SHA1.Create().ComputeHash(Encoding.UTF8.GetBytes(textbox))).Replace("-", "");
                    break;
                default:
                    trfa=false;
                    MessageBox.Show("請選擇加密方式", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;  
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox2.Text.All(char.IsLetterOrDigit) && textBox2.Text.Length >= 8)
            {
                string filePath = "uers.txt";
                string newUsername = textBox1.Text;
                password(comboBox1.Text, textBox2.Text);
                if (trfa)
                {
                    // 讀取所有行
                    string[] lines = File.ReadAllLines(filePath);

                    // 檢查是否已經存在相同的帳號
                    if (lines.Any(line => line.Split('|')[0] == newUsername))
                    {
                        MessageBox.Show("帳號已存在，請使用其他帳號!", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    // 加入新資料
                    string newEntry = $"{newUsername}|{newPasswordHash}";
                    File.AppendAllText(filePath, newEntry + Environment.NewLine);
                    textBox1.Text = textBox2.Text = comboBox1.Text = "";
                    MessageBox.Show("註冊成功!", "成功訊息", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
            }
            else
            {
                MessageBox.Show("輸入正確數值", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox2.Text.All(char.IsLetterOrDigit) && textBox2.Text.Length >= 8)
            {
                string filePath = "uers.txt";
                string newUsername = textBox1.Text;
                password(comboBox1.Text, textBox2.Text);

                if (trfa)
                {
                    // 讀取所有行
                    List<string> lines = File.ReadAllLines(filePath).ToList();

                    // 檢查是否已經存在相同的帳號
                    if (lines.Any(line => line == $"{newUsername}|{newPasswordHash}"))
                    {
                        lines.Remove($"{newUsername}|{newPasswordHash}");
                        File.WriteAllText("uers.txt", "");
                        foreach (string line in lines)
                        {
                            File.AppendAllText("uers.txt", line + Environment.NewLine);
                        }
                        textBox1.Text = textBox2.Text = comboBox1.Text = "";
                        MessageBox.Show("刪除成功", "刪除", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                    else
                    {
                        MessageBox.Show("查無帳號", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("輸入正確數值", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if(textBox4.Text != "" && textBox3.Text != "" && textBox3.Text.All(char.IsLetterOrDigit) && textBox3.Text.Length >= 8)
            {
                string filePath = "uers.txt";
                string newUsername = textBox4.Text;
                password(comboBox2.Text, textBox3.Text);

                // 讀取所有行
                string[] lines = File.ReadAllLines(filePath);

                // 檢查是否已經存在相同的帳號
                if (lines.Any(line => line == $"{newUsername}|{newPasswordHash}"))
                {
                    textBox3.Text = textBox4.Text = comboBox2.Text = "";
                    MessageBox.Show($"歡迎{newUsername}", "成功", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    MessageBox.Show("查無帳密", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("輸入正確數值", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox4.Text = textBox3.Text = "";
            comboBox2.Text = "";
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            textBox2.PasswordChar = checkBox1.Checked ? '\0' : '*';
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            textBox3.PasswordChar = checkBox2.Checked ? '\0' : '*';
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
